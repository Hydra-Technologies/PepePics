package com.example.pepepicsextended;

import java.lang.reflect.Constructor;

public class RowItem {
    public String title;
    public int imageID;

    public RowItem(String title, int imageID) {
        this.title = title;
        this.imageID = imageID;
    }

    public int getImageId() {
        return imageID;
    }

    public String getTitle() {
        return title;
    }
}
