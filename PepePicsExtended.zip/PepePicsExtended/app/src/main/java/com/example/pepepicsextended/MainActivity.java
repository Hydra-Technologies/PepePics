package com.example.pepepicsextended;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.yuyakaido.android.cardstackview.*;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    final int maxLinks = 10;
    Bitmap image;
    ImageView pepe;
    final String[] links = new String[maxLinks];
    private ArrayList<String> pepeLinks = new ArrayList<>();
    int had = 0;

    private CardStackLayoutManager manager;
    private CustomListViewAdapter adapter;

    private ArrayList<String> al;
    private ArrayAdapter<String> arrayAdapter;
    private int i;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //init();

        //initializeCards();

        CardStackView cardStackView = findViewById(R.id.pepeStack);

        manager = new CardStackLayoutManager(this, new CardStackListener() {
            @Override
            public void onCardDragging(Direction direction, float ratio) {

            }

            @Override
            public void onCardSwiped(Direction direction) {

            }

            @Override
            public void onCardRewound() {

            }

            @Override
            public void onCardCanceled() {

            }

            @Override
            public void onCardAppeared(View view, int position) {

            }

            @Override
            public void onCardDisappeared(View view, int position) {

            }
        });

        manager.setStackFrom(StackFrom.None);
        manager.setVisibleCount(3);
        manager.setTranslationInterval(8.0f);
        manager.setScaleInterval(0.95f);
        manager.setSwipeThreshold(0.3f);
        manager.setMaxDegree(20.0f);
        manager.setDirections(Direction.FREEDOM);
        manager.setCanScrollHorizontal(true);
        manager.setSwipeableMethod(SwipeableMethod.Manual);
        manager.setOverlayInterpolator(new LinearInterpolator());
        adapter = new CustomListViewAdapter(addList());
        cardStackView.setLayoutManager(manager);
        cardStackView.setAdapter(adapter);
        cardStackView.setItemAnimator(new DefaultItemAnimator());

    }

    private List<RowItem> addList() {
        List<RowItem> items = new ArrayList<>();
        items.add(new RowItem("Pepe",R.drawable.p000001_sample_pepe_00001));
        items.add(new RowItem("Pepe2",R.drawable.p000001_sample_pepe_00001));
        items.add(new RowItem("Pepe3",R.drawable.p000001_sample_pepe_00001));
        items.add(new RowItem("Pepe4",R.drawable.p000001_sample_pepe_00001));

        return items;
    }


    public void cacheFrogs() {
        for(int i = 0; i<9; i++) {
            Glide.with(this)
                    .load(links[i])
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .preload();
        }
    }

    public void loadFrog(ImageView view) {
        int randInt = (int) (Math.random() * maxLinks);
        for(int i = randInt;i==had;i=randInt) {
            System.out.println(randInt);
            randInt = (int) (Math.random() * maxLinks);
        }

        System.out.println(randInt);
        final int finalRandInt = randInt;

        had = randInt;

        /*Picasso.get()
                .load(links[randInt])
                .networkPolicy(NetworkPolicy.OFFLINE).noFade()
                .into(pepe, new Callback() {
                    @Override
                    public void onSuccess() {

                    }
                    @Override
                    public void onError(Exception e) {
                        //Try again online if cache failed
                        System.out.println("resorting to online");
                        Picasso.get()
                                .load(links[finalRandInt])
                                .error(R.drawable.p000001_sample_pepe_00001)
                                .into(pepe, new Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onError(Exception e) {
                                        Log.v("Picasso", "Could not fetch image");
                                    }
                            });
                    }
            });*/
        Glide.with(this).load(links[randInt]).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(pepe);
}

    public void init() {
        links[0] = "smb://DESKTOP-EB6M3NH/Frens-LessDuplicates/Frens/00001_randomPepe_0x1.jpg";
        links[1] = "https://pngimg.com/uploads/snoop_dogg/snoop_dogg_PNG20.png";
        links[2] = "https://external-preview.redd.it/1RYAwUdiRnc3uAlpxXteyZY2cGcvwJwTwpQjISGwrNw.png?auto=webp&s=c79a217254de72a64ae2632c82aacc649f4acb4a";
        links[3] = "https://png.pngitem.com/pimgs/s/107-1078027_pepe-meme-rarepepe-terrorist-football-pepe-the-frog.png";
        links[4] = "https://www.freeiconspng.com/uploads/pepe-transparent-png-8.png";
        links[5] = "https://i.imgflip.com/31tu3r.png";
        links[6] = "https://images.gutefrage.net/media/fragen/bilder/wieso-darf-man-auf-manchen-seiten-pepe-nicht-als-profilbild-nehmen/0_big.png?v=1553616829000";
        links[7] = "https://assets.popbuzz.com/2017/08/rare-pepe-economy-1487773339-list-handheld-0.png";
        links[8] = "https://cdn.wallpapersafari.com/94/31/wHOvMm.jpg";
        links[9] = "https://www.westfalen-blatt.de/var/storage/images/wb/startseite/owl/lokales/kreis-guetersloh/verl/2629384-weihnachtsmarkt-im-verler-gymnasium-bietet-ein-aussergewoehnliches-programm-schueler-lassen-seifenblasen-brennen/75384262-1-ger-DE/Weihnachtsmarkt-im-Verler-Gymnasium-bietet-ein-aussergewoehnliches-Programm-Schueler-lassen-Seifenblasen-brennen_image_630_420f_wn.jpg";

        cacheFrogs();
    }

    public void initializeCards() {
        //SwipeFlingAdapterView flingContainer = findViewById(R.id.frame);


        /*al = new ArrayList<String>();
        al.add("https://pngimg.com/uploads/ariel/ariel_PNG66.png");
        al.add("https://pngimg.com/uploads/snoop_dogg/snoop_dogg_PNG20.png");
        al.add("https://external-preview.redd.it/1RYAwUdiRnc3uAlpxXteyZY2cGcvwJwTwpQjISGwrNw.png?auto=webp&s=c79a217254de72a64ae2632c82aacc649f4acb4a");
        al.add("https://png.pngitem.com/pimgs/s/107-1078027_pepe-meme-rarepepe-terrorist-football-pepe-the-frog.png");

        ListView listView = new ListView(this);
        arrayAdapter = new ArrayAdapter<String>(this, R.layout.item, R.id.pepeName, al);
        listView.setAdapter(arrayAdapter);
        //arrayAdapter.getView(0,pepe, listView);


        flingContainer.setAdapter(arrayAdapter);
        flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
            @Override
            public void removeFirstObjectInAdapter() {
                Log.d("LIST", "removed object!");
                al.remove(0);
                pepe = findViewById(R.id.currentPepe);
                Glide.with(MainActivity.this).load(al.get(0)).into(pepe);
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object dataObject) {
                Toast.makeText(MainActivity.this, "Left!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRightCardExit(Object dataObject) {
                Toast.makeText(MainActivity.this, "Right!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdapterAboutToEmpty(int itemsInAdapter) {
                al.add("Pepe ".concat(String.valueOf(i)));
                arrayAdapter.notifyDataSetChanged();
                Log.d("LIST", "notified");
                i++;
            }

            @Override
            public void onScroll(float v) {

            }
        });

        flingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int itemPosition, Object dataObject) {
                Toast.makeText(MainActivity.this, "Clicked!", Toast.LENGTH_SHORT).show();
            }
        });*/

    }
}
